"use client";
import Error from "@/components/Error";
import React from "react";

function Page() {
  return <Error />;
}

export default Page;
